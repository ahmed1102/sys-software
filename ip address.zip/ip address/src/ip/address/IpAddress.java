/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip.address;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author n0570451
 */
public class IpAddress {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            String ip = InetAddress.getLocalHost().getHostAddress();
            
            System.out.println(ip);
        } catch (UnknownHostException ex) {
            Logger.getLogger(IpAddress.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Secure;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Ahmed
 */
public class AccountGUI extends javax.swing.JFrame {
    MainClass MC = new MainClass();
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    DefaultListModel dlm = new DefaultListModel();
    String serverIP = "127.0.0.1";
    int Port = 5000;
    int idPort = 1;
    Socket sock;
    Socket sockRecieve;
    BufferedReader reader;
    PrintWriter writer;
    ArrayList<String> userList = new ArrayList();
    Boolean isConnected = false;
    Boolean isConnectedFrdAdd = false;
    Boolean isConnectedFrdRqst = false;
    public static int SOCKET_PORT = 13267;  // you may change this
 public final static String SERVER = "127.0.0.1";  // localhost
  public final static String
       FILE_TO_RECEIVED = "H:downloadedmusic.mp3";  // you may change this, I give a
                                                            // different name because i don't want to
                                                            // overwrite the one used by server...

  public final static int FILE_SIZE = 50000000;
    
    /**
     * Creates new form AccountGUI
     */
    public AccountGUI() {
        initComponents();
        
    }
    
     public class IncomingReader implements Runnable{
        public void run() {
            String[] data;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect", chat = "Chat", chat2 = "Chat2";
            try {
                while ((stream = reader.readLine()) != null) {
                    data = stream.split(":");
                     if (data[2].equals(chat)) {
                            accpost.append(data[0] + ": " + data[1] + "\n");
                            accpost.setCaretPosition(accfriendreq.getDocument().getLength());
                    } else if (data[2].equals(connect)){
                        accpost.removeAll();
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        userRemove(data[0]);
                    } else if (data[2].equals(done)) {
                        acconline.setText("");
                        writeUsers();
                        userList.clear();
                    }
                    else if (data[2].equals(chat2)) {
                       accfriendreq.append(data[1]+"\n");
                       accfriendreq.setCaretPosition(accfriendreq.getDocument().getLength());
                    }
                }
           }catch(Exception ex) {
           }
        }
    } 
     public void ListenThread() {
         Thread IncomingReader = new Thread(new AccountGUI.IncomingReader());
         IncomingReader.start();
    }
    public void userAdd(String data) {
         userList.add(data);
     }
    public void userRemove(String data) {
         accpost.append(data + " has disconnected.\n");
     }
    public void writeUsers() {
         String[] tempList = new String[(userList.size())];
         userList.toArray(tempList);
         for (String token:tempList) {
             acconline.append(token + "\n");
         }
     }
    public void sendDisconnect() {

       String bye = (accusername.getText() + ": :Disconnect");
        try{
            writer.println(bye); // Sends server the disconnect signal.
            writer.flush(); // flushes the buffer
        } catch (Exception e) {
            accpost.append("Could not send Disconnect message.\n");
        }
      }

    public void Disconnect() {
        try {
               accpost.append("Disconnected.\n");
               sock.close();
        } catch(Exception ex) {
               accpost.append("Failed to disconnect. \n");
        }
        isConnected = false;
       // usernameField.setEditable(true);
        //usersList.setText("");
      }
    
  

    /**
     * This method is called from within the constructor to initialise the form.
   
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        GUI = new javax.swing.JTabbedPane();
        LoginP = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        logusername = new javax.swing.JTextField();
        logpassword = new javax.swing.JPasswordField();
        cmd_login = new javax.swing.JButton();
        RegisterP = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        ck_Pop = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        regmusicPick = new javax.swing.JTextArea();
        ck_RB = new javax.swing.JCheckBox();
        ck_Rock = new javax.swing.JCheckBox();
        ck_Opera = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        btn_CheckBox = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        regusername = new javax.swing.JTextField();
        regplaceofbirth = new javax.swing.JTextField();
        regdateofbirth = new javax.swing.JTextField();
        regpassword = new javax.swing.JTextField();
        cmd_register = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        AccountP = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        image = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        UserP = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        accusername = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        accmusic = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        accpost = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        accsend = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        accmsgpost = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        acconline = new javax.swing.JTextArea();
        accrequest = new javax.swing.JButton();
        accchat = new javax.swing.JButton();
        accaccept = new javax.swing.JButton();
        accrefuse = new javax.swing.JButton();
        accdateofbirth = new javax.swing.JTextField();
        accplaceofbirth = new javax.swing.JTextField();
        friend = new javax.swing.JTextField();
        download = new javax.swing.JButton();
        btn_select = new javax.swing.JButton();
        btn_stop = new javax.swing.JButton();
        cmd_musicattachsend = new javax.swing.JButton();
        btn_play = new javax.swing.JButton();
        regmusicfile = new javax.swing.JTextField();
        share = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        accfriendreq = new javax.swing.JTextArea();
        hostButton = new javax.swing.JButton();
        joinButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        accfriend = new javax.swing.JList<>();
        jLabel13 = new javax.swing.JLabel();
        friendRqst = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 836, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 768, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LoginP.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Music Social Network - Login");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel4.setText("Username:");

        jLabel5.setText("Password:");

        cmd_login.setText("Login");
        cmd_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_loginActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout LoginPLayout = new javax.swing.GroupLayout(LoginP);
        LoginP.setLayout(LoginPLayout);
        LoginPLayout.setHorizontalGroup(
            LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(LoginPLayout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addGroup(LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cmd_login)
                    .addGroup(LoginPLayout.createSequentialGroup()
                        .addGroup(LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(logpassword)
                            .addComponent(logusername, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(278, Short.MAX_VALUE))
        );
        LoginPLayout.setVerticalGroup(
            LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginPLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95)
                .addGroup(LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(logusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(LoginPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(logpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(112, 112, 112)
                .addComponent(cmd_login)
                .addGap(0, 459, Short.MAX_VALUE))
        );

        GUI.addTab("Login", LoginP);

        RegisterP.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Music Social Network - New Registration");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        ck_Pop.setBackground(new java.awt.Color(255, 255, 255));
        ck_Pop.setText("Pop");

        regmusicPick.setColumns(20);
        regmusicPick.setRows(5);
        jScrollPane1.setViewportView(regmusicPick);

        ck_RB.setBackground(new java.awt.Color(255, 255, 255));
        ck_RB.setText("R&B");

        ck_Rock.setBackground(new java.awt.Color(255, 255, 255));
        ck_Rock.setText("Rock");

        ck_Opera.setBackground(new java.awt.Color(255, 255, 255));
        ck_Opera.setText("Opera");

        jLabel6.setText("Music Profile:");

        btn_CheckBox.setText("Add");
        btn_CheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CheckBoxActionPerformed(evt);
            }
        });

        jLabel7.setText("Username:");

        jLabel8.setText("Password:");

        jLabel9.setText("Date Of Birth:");

        jLabel10.setText("Place Of Birth:");

        cmd_register.setText("Register");
        cmd_register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_registerActionPerformed(evt);
            }
        });

        jLabel11.setText("Or");

        jLabel12.setText("Cancel");

        javax.swing.GroupLayout RegisterPLayout = new javax.swing.GroupLayout(RegisterP);
        RegisterP.setLayout(RegisterPLayout);
        RegisterPLayout.setHorizontalGroup(
            RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(RegisterPLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(cmd_register)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(RegisterPLayout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(RegisterPLayout.createSequentialGroup()
                            .addComponent(jLabel10)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(regplaceofbirth, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RegisterPLayout.createSequentialGroup()
                            .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(regusername, javax.swing.GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
                                .addComponent(regpassword)
                                .addComponent(regdateofbirth))))
                    .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(RegisterPLayout.createSequentialGroup()
                            .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(ck_Opera, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(RegisterPLayout.createSequentialGroup()
                                    .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel6)
                                        .addComponent(ck_Rock)
                                        .addComponent(ck_Pop)
                                        .addComponent(ck_RB))
                                    .addGap(118, 118, 118)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_CheckBox))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 272, Short.MAX_VALUE))
        );
        RegisterPLayout.setVerticalGroup(
            RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RegisterPLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(99, 99, 99)
                .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RegisterPLayout.createSequentialGroup()
                        .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(regusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(regpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RegisterPLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(regplaceofbirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(RegisterPLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(regdateofbirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(66, 66, 66)
                .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RegisterPLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(3, 3, 3)
                        .addComponent(ck_Opera))
                    .addComponent(btn_CheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ck_Rock)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ck_Pop)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ck_RB)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 216, Short.MAX_VALUE)
                .addGroup(RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmd_register, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RegisterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(jLabel12)))
                .addGap(21, 21, 21))
        );

        GUI.addTab("Register", RegisterP);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jDesktopPane2.setLayer(image, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane2Layout = new javax.swing.GroupLayout(jDesktopPane2);
        jDesktopPane2.setLayout(jDesktopPane2Layout);
        jDesktopPane2Layout.setHorizontalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(image, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jDesktopPane2Layout.setVerticalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(image, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel22.setText("Profile Picture:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(680, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jDesktopPane2)
                        .addGap(126, 126, 126))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(189, 189, 189))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDesktopPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(542, Short.MAX_VALUE))
        );

        AccountP.addTab("Profile", jPanel4);

        UserP.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("NTU Music Social Network Username:");

        accusername.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        accusername.setText("Jon");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(accusername, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 244, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(accusername))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Friends:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("Information:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("Shared Songs:");

        accmusic.setColumns(20);
        accmusic.setRows(5);
        jScrollPane4.setViewportView(accmusic);

        accpost.setColumns(20);
        accpost.setRows(5);
        jScrollPane5.setViewportView(accpost);

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel18.setText("Friends Posts");

        accsend.setText("Send");
        accsend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accsendActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel19.setText("Post:");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel20.setText("List of connected people:");

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Friendship Request from:");

        acconline.setColumns(20);
        acconline.setRows(5);
        jScrollPane6.setViewportView(acconline);

        accrequest.setText("Request Friendship");
        accrequest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accrequestActionPerformed(evt);
            }
        });

        accchat.setText("Chat");

        accaccept.setText("Accept");
        accaccept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accacceptActionPerformed(evt);
            }
        });

        accrefuse.setText("Refuse");

        friend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendActionPerformed(evt);
            }
        });

        download.setText("Download");
        download.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                downloadActionPerformed(evt);
            }
        });

        btn_select.setText("...");
        btn_select.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btn_selectMouseReleased(evt);
            }
        });

        btn_stop.setText("Stop");
        btn_stop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btn_stopMouseReleased(evt);
            }
        });
        btn_stop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_stopActionPerformed(evt);
            }
        });

        cmd_musicattachsend.setText("Attach Music");
        cmd_musicattachsend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_musicattachsendActionPerformed(evt);
            }
        });

        btn_play.setText("Play");
        btn_play.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btn_playMouseReleased(evt);
            }
        });
        btn_play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_playActionPerformed(evt);
            }
        });

        regmusicfile.setText("Select Music:");

        share.setText("Share");
        share.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shareActionPerformed(evt);
            }
        });

        accfriendreq.setColumns(20);
        accfriendreq.setRows(5);
        jScrollPane7.setViewportView(accfriendreq);

        hostButton.setText("Host Chat");
        hostButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hostButtonActionPerformed(evt);
            }
        });

        joinButton.setText("Join Chat");
        joinButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joinButtonActionPerformed(evt);
            }
        });

        accfriend.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "ahmed" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(accfriend);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("Type name of friend to add:");

        friendRqst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendRqstActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Type name of friend to accept:");

        javax.swing.GroupLayout UserPLayout = new javax.swing.GroupLayout(UserP);
        UserP.setLayout(UserPLayout);
        UserPLayout.setHorizontalGroup(
            UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(UserPLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, UserPLayout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(18, 18, 18)
                                .addComponent(accmsgpost)
                                .addGap(18, 18, 18)
                                .addComponent(accsend))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UserPLayout.createSequentialGroup()
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel20)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(39, 39, 39)
                                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(accrequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(accchat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(friend)
                                            .addComponent(jLabel13))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(accaccept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(accrefuse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(friendRqst)
                                            .addComponent(jLabel14)))
                                    .addComponent(jLabel21)))
                            .addGroup(UserPLayout.createSequentialGroup()
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(77, 77, 77)
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(accdateofbirth, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(accplaceofbirth, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(regmusicfile, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(hostButton)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(download, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cmd_musicattachsend, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(joinButton)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(share, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(btn_select, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addComponent(btn_stop, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)
                                        .addComponent(btn_play, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17))))
                        .addGap(24, 24, 24))))
        );

        UserPLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {download, hostButton, joinButton});

        UserPLayout.setVerticalGroup(
            UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UserPLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UserPLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)))
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(UserPLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                                .addComponent(accdateofbirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(accplaceofbirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(download)
                                    .addComponent(hostButton))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(share)
                                    .addComponent(joinButton))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmd_musicattachsend))
                            .addGroup(UserPLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btn_stop)
                                .addComponent(btn_play))
                            .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btn_select)
                                .addComponent(regmusicfile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(accsend)
                    .addComponent(jLabel19)
                    .addComponent(accmsgpost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(UserPLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane7)
                            .addGroup(UserPLayout.createSequentialGroup()
                                .addGroup(UserPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addGap(15, 15, 15)
                                        .addComponent(friendRqst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(accaccept)
                                        .addGap(18, 18, 18)
                                        .addComponent(accrefuse))
                                    .addGroup(UserPLayout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(12, 12, 12)
                                        .addComponent(friend, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(accrequest)
                                        .addGap(18, 18, 18)
                                        .addComponent(accchat)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(60, 60, 60))
        );

        AccountP.addTab("User", UserP);

        GUI.addTab("Account", AccountP);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(GUI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(GUI, javax.swing.GroupLayout.PREFERRED_SIZE, 824, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_CheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CheckBoxActionPerformed
        // TODO add your handling code here:
        String s1 ="";
        if(ck_Opera.isSelected()){
            s1 = s1 + "" + ck_Opera.getText() + '\n';
        }
        if(ck_Rock.isSelected()){
            s1 = s1 + "" + ck_Rock.getText() + '\n';
        }
        if(ck_Pop.isSelected()){
            s1 = s1 + "" + ck_Pop.getText() + '\n';
        }
        if(ck_RB.isSelected()){
            s1 = s1 + "" + ck_RB.getText() + '\n';
        }
        regmusicPick.setText(s1);
    }//GEN-LAST:event_btn_CheckBoxActionPerformed

    private void cmd_registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_registerActionPerformed
        // TODO add your handling code here:
        conn=MySqlConnect.ConnectDB();
        try{
            String reg = "Insert into login (Username,Password,DateOfBirth,PlaceOfBirth,ProfilePicture,MusicLike,Music) values (?,?,?,?,?,?,?)";
            
            pst=conn.prepareStatement(reg);
            pst.setString(1,regusername.getText());
            pst.setString(2,regpassword.getText());
            pst.setString(3,regdateofbirth.getText());
            pst.setString(4,regplaceofbirth.getText());
            pst.setString(6,regmusicPick.getText());
           
            
            pst.execute();
            
            JOptionPane.showMessageDialog(null,"Successfully Registered");
            regusername.setText("");
            regpassword.setText("");
            regdateofbirth.setText("");
            regplaceofbirth.setText("");
            regmusicPick.setText("");
           

        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_cmd_registerActionPerformed

    private void cmd_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_loginActionPerformed
        // TODO add your handling code here:
        
         conn=MySqlConnect.ConnectDB();
        String Sql="Select * from login where username=? and password=?";
        try
        {
            pst=conn.prepareStatement(Sql);
            pst.setString(1,logusername.getText());
            pst.setString(2,logpassword.getText());
            rs=pst.executeQuery();
            if(rs.next())
            {
                JOptionPane.showMessageDialog(null, "Welcome user");
                String add = rs.getString("Username");
                accusername.setText(add);
                String add2 = rs.getString("DateOfBirth") + '\n';
                accdateofbirth.setText(add2);
                String add3 = rs.getString("PlaceOfBirth") + '\n';
                accplaceofbirth.setText(add3);
                idPort =  ((Number) rs.getObject(1)).intValue();
                accfriend.setModel(dlm);
                
                byte[]imagedata=rs.getBytes("ProfilePicture");
                format = new ImageIcon(imagedata);
                image.setIcon(format);
                
               
        
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Invalid username or password", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        
        if (isConnected == false) {
            //username = usernameField.getText();
           // usernameField.setEditable(false);
            try {
                sock = new Socket(serverIP, Port);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writer = new PrintWriter(sock.getOutputStream());
                writer.println(accusername.getText() + ":has connected.:Connect"); // Displays to everyone that user connected.
                
                writer.flush(); // flushes the buffer
                isConnected = true; // Used to see if the client is connected.
            } catch (Exception ex) {
                accpost.append("Cannot Connect! Try Again. \n");
               // usernameField.setEditable(true);
            }
            ListenThread();
        } else if (isConnected == true) {
            accpost.append("You are already connected. \n");
        }  

    }//GEN-LAST:event_cmd_loginActionPerformed

    private void accsendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accsendActionPerformed
        // TODO add your handling code here:
        
         String nothing = "";
        if ((accmsgpost.getText()).equals(nothing)) {
            accmsgpost.setText("");
            accmsgpost.requestFocus();
        } else {
            try {
               writer.println(accusername.getText() + ":" + accmsgpost.getText() + ":" + "Chat");
               writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                accpost.append("Message was not sent. \n");
            }
            accmsgpost.setText("");
            accmsgpost.requestFocus();
        }

        accmsgpost.setText("");
        accmsgpost.requestFocus();
    }//GEN-LAST:event_accsendActionPerformed

    private void accrequestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accrequestActionPerformed
        // TODO add your handling code here:
        String Temp;
        String[] lines = acconline.getText().split("\n");
        for (String line : lines)
        {
           if (line.equals(friend.getText()))
           {
              // Temp = "###FRR" + line;
            try {
               writer.println(accusername.getText() + ":" + line +":" + "Chat2");
               writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                accpost.append("Message was not sent. \n");
            }
           }
        }
        lines = new String[0];
        //String Temp;
       // Temp = "###FRR" + this.accfriend.getSelectedValue();
      
    }//GEN-LAST:event_accrequestActionPerformed

    private void friendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_friendActionPerformed

    private void downloadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downloadActionPerformed
        // TODO add your handling code here:
        int bytesRead;
        int current = 0;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        Socket sock = null;
        String Sql3="Select * from login where username=?";
        try
        {
            pst=conn.prepareStatement(Sql3);
            pst.setString(1,accfriend.getSelectedValue());
            rs=pst.executeQuery();
            if(rs.next())
            {
                int tempPort =  ((Number) rs.getObject(1)).intValue();
                try {
                
            sock = new Socket(SERVER, tempPort);
            System.out.println("Connecting...");

            // receive file
            byte [] mybytearray  = new byte [FILE_SIZE];
            InputStream is = sock.getInputStream();
            fos = new FileOutputStream(FILE_TO_RECEIVED);
            bos = new BufferedOutputStream(fos);
            bytesRead = is.read(mybytearray,0,mybytearray.length);
            current = bytesRead;

            do {
                bytesRead =
                is.read(mybytearray, current, (mybytearray.length-current));
                if(bytesRead >= 0) current += bytesRead;
            } while(bytesRead > -1);

            bos.write(mybytearray, 0 , current);
            bos.flush();
            System.out.println("File " + FILE_TO_RECEIVED
                + " downloaded (" + current + " bytes read)");
        }
        catch (IOException ex) {
            Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
        }    finally {
            if (fos != null) try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (bos != null) try {
                bos.close();
            } catch (IOException ex) {
                Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (sock != null) try {
                sock.close();
            } catch (IOException ex) {
                Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Song Downloaded");
        }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Invalid username or password", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
             }catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_downloadActionPerformed

    private void btn_selectMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_selectMouseReleased
        // TODO add your handling code here:
        FileFilter filter = new FileNameExtensionFilter ("MP3 Files", "mp3", "mpe3");
        JFileChooser chooser = new JFileChooser("E:\\AllMyLife.m4a");

        int returnVal = chooser.showOpenDialog(null);

        if(returnVal == JFileChooser.APPROVE_OPTION){

            File myFile = chooser.getSelectedFile();
            String song = myFile +"";

            MC.play(song);
        }
    }//GEN-LAST:event_btn_selectMouseReleased

    private void btn_stopMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_stopMouseReleased
        // TODO add your handling code here:

        MC.stop();
    }//GEN-LAST:event_btn_stopMouseReleased

    private void btn_stopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_stopActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_stopActionPerformed

    private void cmd_musicattachsendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_musicattachsendActionPerformed
        // TODO add your handling code here:

        JFileChooser ch = new JFileChooser();
        ch.showOpenDialog(null);
        File f= ch.getSelectedFile();
        picturefilename = f.getAbsolutePath();
        regmusicfile.setText(picturefilename);

        try{
            File music = new File(picturefilename);
            FileInputStream fs = new FileInputStream(music);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            for (int readNum; (readNum=fs.read(buf))!=-1;){
                bos.write(buf,0,readNum);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_cmd_musicattachsendActionPerformed

    private void btn_playMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_playMouseReleased
        // TODO add your handling code here:
        MC.play("H:\\AllMyLife.m4a");
    }//GEN-LAST:event_btn_playMouseReleased

    private void btn_playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_playActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_playActionPerformed

    private void shareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shareActionPerformed
        // TODO add your handling code here:
        new Thread(new Runnable() {
            public void run() {
                try {
               writer.println(accusername.getText() + ": Hi I've shared my song for you to download :" + "Chat");
               writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                accpost.append("Message was not sent. \n");
            }
                JOptionPane.showMessageDialog(null, "Song Uploaded");
                //SOCKET_PORT = idPort;
                FileInputStream fis = null;
                BufferedInputStream bis = null;
                OutputStream os = null;
                ServerSocket servsock = null;
                Socket sock = null;
                try {
                    servsock = new ServerSocket(idPort);
                    while (true) {
                        System.out.println("Waiting...");
                        try {
                            sock = servsock.accept();
                            System.out.println("Accepted connection : " + sock);
                            // send file
                            File myFile = new File (regmusicfile.getText());
                            byte [] mybytearray  = new byte [(int)myFile.length()];
                            fis = new FileInputStream(myFile);
                            bis = new BufferedInputStream(fis);
                            bis.read(mybytearray,0,mybytearray.length);
                            os = sock.getOutputStream();
                            System.out.println("Sending " + regmusicfile.getText() + "(" + mybytearray.length + " bytes)");
                            os.write(mybytearray,0,mybytearray.length);
                            os.flush();
                            System.out.println("Done.");
                        }
                        finally {
                            if (bis != null) bis.close();
                            if (os != null) os.close();
                            if (sock!=null) sock.close();
                        }

                    }

                }
                catch (IOException ex) {
                    Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
                }    finally {
                    if (servsock != null) try {
                        servsock.close();
                    } catch (IOException ex) {
                        Logger.getLogger(AccountGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }).start();

        new Thread(new Runnable() {
            public void run() {
                run();
            }
        }).start();
    }//GEN-LAST:event_shareActionPerformed

    private void hostButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hostButtonActionPerformed
        // TODO add your handling code here:
        ServerWindow s= new ServerWindow();
        s.port = idPort;
        s.setVisible(true);
        ChatMain c= new ChatMain();
        c.username = accusername.getText();
        c.Port = idPort;
        c.setVisible((true));   
    }//GEN-LAST:event_hostButtonActionPerformed

    private void joinButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joinButtonActionPerformed
        // TODO add your handling code here:
        String Sql2="Select * from login where username=?";
       // String Sql2="Select idLogin from login where username=? and password=?";
        try
        {
            pst=conn.prepareStatement(Sql2);
            pst.setString(1,accfriend.getSelectedValue());
            rs=pst.executeQuery();
            if(rs.next())
            {
                int val =  ((Number) rs.getObject(1)).intValue();
                ChatMain c= new ChatMain();
                c.Port = val;
                c.username = accusername.getText();
                c.setVisible((true));
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Invalid username or password", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
             }catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_joinButtonActionPerformed

    private void friendRqstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendRqstActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_friendRqstActionPerformed

    private void accacceptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accacceptActionPerformed
        // TODO add your handling code here:
        String Temp;
        String[] lines = accfriendreq.getText().split("\n");
        for (String line : lines)
        {
           if (line.equals(friendRqst.getText()))
           {
               dlm.addElement(line);
               
           }
        }
        lines = new String[0];
    }//GEN-LAST:event_accacceptActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccountGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccountGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccountGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccountGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccountGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane AccountP;
    private javax.swing.JTabbedPane GUI;
    private javax.swing.JPanel LoginP;
    private javax.swing.JPanel RegisterP;
    private javax.swing.JPanel UserP;
    private javax.swing.JButton accaccept;
    private javax.swing.JButton accchat;
    private javax.swing.JTextField accdateofbirth;
    private javax.swing.JList<String> accfriend;
    private javax.swing.JTextArea accfriendreq;
    private javax.swing.JTextField accmsgpost;
    private javax.swing.JTextArea accmusic;
    public static javax.swing.JTextArea acconline;
    private javax.swing.JTextField accplaceofbirth;
    private javax.swing.JTextArea accpost;
    private javax.swing.JButton accrefuse;
    private javax.swing.JButton accrequest;
    private javax.swing.JButton accsend;
    private javax.swing.JLabel accusername;
    private javax.swing.JButton btn_CheckBox;
    private javax.swing.JButton btn_play;
    private javax.swing.JButton btn_select;
    private javax.swing.JButton btn_stop;
    private javax.swing.JCheckBox ck_Opera;
    private javax.swing.JCheckBox ck_Pop;
    private javax.swing.JCheckBox ck_RB;
    private javax.swing.JCheckBox ck_Rock;
    private javax.swing.JButton cmd_login;
    private javax.swing.JButton cmd_musicattachsend;
    private javax.swing.JButton cmd_register;
    private javax.swing.JButton download;
    private javax.swing.JTextField friend;
    private javax.swing.JTextField friendRqst;
    private javax.swing.JButton hostButton;
    private javax.swing.JLabel image;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JButton joinButton;
    private javax.swing.JPasswordField logpassword;
    private javax.swing.JTextField logusername;
    private javax.swing.JTextField regdateofbirth;
    private javax.swing.JTextArea regmusicPick;
    private javax.swing.JTextField regmusicfile;
    private javax.swing.JTextField regpassword;
    private javax.swing.JTextField regplaceofbirth;
    private javax.swing.JTextField regusername;
    private javax.swing.JButton share;
    // End of variables declaration//GEN-END:variables
String musicfilename=null;


String picturefilename=null;


 private ImageIcon format = null;



}


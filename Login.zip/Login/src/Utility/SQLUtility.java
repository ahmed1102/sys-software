package Utility;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmed
 */
public class SQLUtility {
   static String driver = "com.mysql.jdbc.Driver";
   static String DB_Username = "root";
   static String DB_Password = "";
   static String DB_Url = "mysql:jdbc://localhost:3306/user1";
    
    public static Connection getConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
        Connection con = null;
        Class.forName(driver).newInstance();
        con = DriverManager.getConnection(DB_Url, DB_Username, DB_Password);
        
        return con;
    }
            
    
}

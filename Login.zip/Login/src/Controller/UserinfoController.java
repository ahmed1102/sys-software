/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Utility.SQLUtility;
import Model.UserInfo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ahmed
 */
public class UserinfoController {
    UserInfo user = new UserInfo();
    
    public boolean isVaildUser(){
        
        String sql = "select * from userinfo"
                + "where username  = '"+user.getUserName()+"'"
                + " and password = '"+user.getPassword()+"'";
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con= SQLUtility.getConnection();
        } catch (InstantiationException ex) {
            Logger.getLogger(UserinfoController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(UserinfoController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UserinfoController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UserinfoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
            if (rs.next())
                return true;
        } catch (SQLException ex) {
            Logger.getLogger(UserinfoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
    return false;
    }

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }
    
}
